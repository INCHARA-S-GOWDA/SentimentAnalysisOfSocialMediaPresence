import matplotlib.pyplot as plt
import pandas as pd
import streamlit as st
import pickle
import os
import time
from tqdm import tqdm
import re
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
import string
import nltk
import warnings
warnings.filterwarnings("ignore", category=DeprecationWarning)

model = pickle.load(open(r'C:\Users\Inchara\Downloads\SAoSMP\Pickle-File\pickle.pkl', 'rb'))

st.title("Twitter Sentiment Prediction Application")

uploaded_file = st.file_uploader('Choose your "Customer Tweets Data" File')
time.sleep(20)
#-------------------------------------------------------
progress_text = "Customer Tweets Data File reading is in progress. Please wait. ⏳"
my_progress_bar = st.progress(0)
status_text = st.empty()

for percent_complete in range(0, 101):
    time.sleep(0.02)
    my_progress_bar.progress(percent_complete)
    status_text.text(f"{progress_text} {percent_complete}%")

status_text.text("Customer Tweets Data file reading is completed! ⌛")
my_progress_bar.empty()
#--------------------------------------------------------

if uploaded_file is not None:
  df = pd.read_csv(uploaded_file)
  st.text('Input Customer file Data')
  st.write(df)

time.sleep(5)

st.text('Customer Data Preprocessing starts...')
#-------------------------------------------------------
progress_text = "Data Preprocessing is in progress. Please wait. ⏳"
my_progress_bar = st.progress(0)
status_text = st.empty()

for percent_complete in range(0, 101):
    time.sleep(0.02)
    my_progress_bar.progress(percent_complete)
    status_text.text(f"{progress_text} {percent_complete}%")

status_text.text("Data Preprocessing is completed! ⌛")
my_progress_bar.empty()
#--------------------------------------------------------
def remove_pattern(text,pattern):

    # re.findall() finds the pattern i.e @user and puts it in a list for further task
    r = re.findall(pattern,text)

    # re.sub() removes @user from the sentences in the dataset
    for i in r:
        text = re.sub(i,"",text)

    return text

df['Tidy_Tweets'] = np.vectorize(remove_pattern)(df['tweet'], "@[\w]*")

df['Tidy_Tweets'] = df['Tidy_Tweets'].str.replace("[^a-zA-Z#]", " ")

df['Tidy_Tweets'] = df['Tidy_Tweets'].apply(lambda x: ' '.join([w for w in x.split() if len(w)>3]))

tokenized_tweet = df['Tidy_Tweets'].apply(lambda x: x.split())

from nltk import PorterStemmer

ps = PorterStemmer()

tokenized_tweet = tokenized_tweet.apply(lambda x: [ps.stem(i) for i in x])

for i in range(len(tokenized_tweet)):
    tokenized_tweet[i] = ' '.join(tokenized_tweet[i])
df['Tidy_Tweets'] = tokenized_tweet

from sklearn.feature_extraction.text import TfidfVectorizer

tfidf=TfidfVectorizer(max_df=0.90, min_df=2,max_features=1000,stop_words='english')

tfidf_matrix=tfidf.fit_transform(df['Tidy_Tweets'])

df_tfidf = pd.DataFrame(tfidf_matrix.todense())

train_tfidf_matrix = tfidf_matrix
time.sleep(5)
st.text('Customer Data based Sentiment Prediction process starts...')
time.sleep(5)
prediction = model.predict(train_tfidf_matrix)
df["label"]=prediction

df['Pred_Value'] = df['label'].map({0: 'negative', 1: 'positive'})
df1 = df[['id', 'tweet', 'label', 'Pred_Value']]

#-------------------------------------------------------
progress_text = "Prediction process is in progress. Please wait. ⏳"
my_progress_bar = st.progress(0)
status_text = st.empty()

for percent_complete in range(0, 101):
    time.sleep(0.02)
    my_progress_bar.progress(percent_complete)
    status_text.text(f"{progress_text} {percent_complete}%")

status_text.text("Prediction Process is completed! ⌛")
my_progress_bar.empty()

df2=df1
st.text('Customer Data with Predicted Values')
st.write(df2)
time.sleep(5)

st.text('Customer Data file with Predicted values downloading Process starts...')
time.sleep(5)

def convert_df(df2):
    return df2.to_csv().encode('utf-8')

csv1 = convert_df(df2)
df2.to_csv(r"C:\Users\Inchara\Downloads\SAoSMP\Frontend\Customer_Tweets_Predicted_through_Frontend.csv", index = False)

#-------------------------------------------------------
progress_text = "Downloading of CSV file is in progress. Please wait. ⏳"
my_progress_bar = st.progress(0)
status_text = st.empty()

for percent_complete in range(0, 101):
    time.sleep(0.02)
    my_progress_bar.progress(percent_complete)
    status_text.text(f"{progress_text} {percent_complete}%")

status_text.text("File has been downloaded! ⌛")
my_progress_bar.empty()
time.sleep(5)
st.text('Downloaded file "Customer_Tweets_Predicted_through_Frontend.csv" is in your "Frontend" folder')
