import streamlit as st
import pandas as pd
import numpy as np
import plotly.express as px
from wordcloud import WordCloud, STOPWORDS
import matplotlib.pyplot as plt
import warnings

# Suppressing DeprecationWarning
warnings.filterwarnings("ignore", category=DeprecationWarning)

st.title("Tweets Sentiments Prediction Dashboard")

st.sidebar.title("Options")

@st.cache_data
def load_data():
    data = pd.read_csv(r'C:\Users\Inchara\Downloads\SAoSMP\Frontend\Customer_Tweets_Predicted_through_Frontend.csv')
    return data

data = load_data()

st.sidebar.subheader("Tweets Sentiments Prediction Display Options")

plot_type = st.sidebar.selectbox('Type', ['Histogram', 'Pie-chart'], key='rollno1')
sentiment_count = data['Pred_Value'].value_counts()

st.write(sentiment_count)
sentiment_count = pd.DataFrame({'Sentiment': sentiment_count.index, 'Tweets': sentiment_count.values})
if st.sidebar.checkbox('Show', False, key='rollno2'):
    st.markdown('### Count of Tweets by Sentiment Types')
    if plot_type == 'Histogram':
        fig = px.bar(sentiment_count, x='Sentiment', y='Tweets', color='Tweets', height=550)
        st.plotly_chart(fig)
    else:
        fig = px.pie(sentiment_count, values='Tweets', names='Sentiment')
        st.plotly_chart(fig)

st.set_option('deprecation.showPyplotGlobalUse', False)
st.sidebar.header('WordCloud')
word_sentiment = st.sidebar.radio('Select Sentiment', ('negative', 'positive'))
refresh_data = st.sidebar.checkbox('Refresh Data')

# Manual refresh of data
if refresh_data:
    data = load_data()

if st.sidebar.checkbox('Show', True, key='rollno5'):
    st.header('WordCloud for {0} Sentiment'.format(word_sentiment))
    df = data[data['Pred_Value'] == word_sentiment]
    words = ' '.join(df['tweet'])
    pre_process = ' '.join([word for word in words.split() if 'http' not in word and not word.startswith('@') and word != 'RT'])
    wc = WordCloud(stopwords=STOPWORDS, background_color='#000', height=550, width=550).generate(pre_process)
    plt.imshow(wc)
    plt.xticks([])
    plt.yticks([])
    st.pyplot()
